<u><b>Note</b></u>: If you are using a Windows 7 OS, you will need to install the SAMD drivers using the [SAMD Windows7 Installer](https://github.com/sparkfun/samd_windows7_installer/releases).
